package com.lti.project.services;

import java.util.List;

import com.lti.project.entity.Scholarship;
import com.lti.project.exception.ScholarshipException;

public interface ScholarshipService 
{
	public List<Scholarship> getStudList() throws ScholarshipException;
	public List<Scholarship> getMinStudList() throws ScholarshipException;
	public Scholarship getApplDetails(long applicationId)  throws ScholarshipException; 
	public Scholarship setApplicationStatus(Scholarship scholarship)  throws ScholarshipException; 
	public Scholarship insertNewScholarship(Scholarship scholarship) throws ScholarshipException;
}
