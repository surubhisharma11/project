package com.lti.project.eligibility;

import org.springframework.stereotype.Service;

import com.lti.project.entity.Registration;
import com.lti.project.entity.Scholarship;


@Service("Pragati")
public class Pragati implements CheckPragatiEligibility
{

	public String CheckPragatiEligibility(Registration registration, Scholarship scholarship) 
	{
		String maritalStaus = scholarship.getMaritalStatus();
		long familyAnnualIncome = scholarship.getFamilyAnnualIncome();
		String gender = registration.getGender();

		if( gender.equals("Female") && maritalStaus.equals("Married") && (familyAnnualIncome<800000))
		{
			return "true";

		}
		else 
		
		if( gender.equals("Female") && maritalStaus.equals("Unmarried") && (familyAnnualIncome<800000))
		{
			return "true";

		}	
		else	
		{
			return "false";
		}
		
	}

}
