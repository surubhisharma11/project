package com.lti.project.services;

import java.util.List;

import com.lti.project.entity.InstituteRegistration;
import com.lti.project.exception.RegistrationException;

public interface InstituteRegistrationService 
{
	public InstituteRegistration insertNewInstitute(InstituteRegistration instituteRegistration) throws RegistrationException;	
	public List<InstituteRegistration> getInsList() throws RegistrationException;
	public InstituteRegistration getInsDetails(long instituteCode) throws RegistrationException;
}
