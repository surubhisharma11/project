package com.lti.project.eligibility;

import com.lti.project.entity.Registration;
import com.lti.project.entity.Scholarship;

public interface CheckPragatiEligibility 
{
	public String CheckPragatiEligibility(Registration registration , Scholarship scholarship);
}
