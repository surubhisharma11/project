package com.lti.project.controllers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller("FileDisplayController")
public class FileDisplayController 

{
	
    @Autowired
	ServletContext context;
    
    
    
    //file upload path :  C:\\Users\\Akshay\\Desktop\\Workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Project_trial
    @RequestMapping("/displayPdf/{applicationId}/{fileName}")
    public String displayPdf(HttpServletRequest request, HttpServletResponse response, @PathVariable("fileName") String fileName, @PathVariable("applicationId") String applicationId)
    {
        File file = new File("D:\\projectGladiator\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp5\\wtpwebapps\\Project_trial\\Uploaded Documents\\" 
				 + applicationId + "_" + fileName + ".pdf");
        response.setHeader("Content-Type", context.getMimeType(file.getName()));
        response.setHeader("Content-Length", String.valueOf(file.length()));
        response.setHeader("Content-Disposition", "inline; filename=\"" + fileName + ".pdf\"");
        request.setAttribute("fileName", fileName);
        try 
        {
			Files.copy(file.toPath(), response.getOutputStream());
			response.getOutputStream().flush();
			response.getOutputStream().close();
			
		} 
        catch (IOException e) 
        {
        	//System.out.println("in catch");
        	return "errorPage";
						//request.setAttribute("errorMessage", "Error displaying pdf.");
		}
        
		return null;
    }
}
