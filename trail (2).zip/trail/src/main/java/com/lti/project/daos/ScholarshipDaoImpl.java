package com.lti.project.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.HibernateException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.project.entity.Scholarship;
import com.lti.project.exception.ScholarshipException;

@Repository
public class ScholarshipDaoImpl implements ScholarshipDao
{
	@PersistenceContext
	private EntityManager entityManager;
	
	
	//************institute student list***********************

	public List<Scholarship> getStudList() throws ScholarshipException 
	{
		try
		{
			Query qry=entityManager.createNamedQuery("allStudent");
			return qry.getResultList();
		}
	
		catch(Exception e)
		{
			throw new ScholarshipException("OOP's!!! Something went wrong while listing students", e);
		}
	}
	
	
	//*************ministry student list***********************
	public List<Scholarship> getMinStudList() throws ScholarshipException 
	{
		try
		{
			Query qry=entityManager.createNamedQuery("allMinStudent");
			return qry.getResultList();
			
		}
		catch(Exception e)
		{
			throw new ScholarshipException("OOP's!!! Something went wrong while listing students", e);
		}
	}

	public Scholarship getApplDetails(long applicationId) throws ScholarshipException 
	{
		try
		{
			Scholarship applDetails=entityManager.find(Scholarship.class,applicationId);
			return applDetails;
		}
		catch(Exception e)
		{
			throw new ScholarshipException("OOP's!!! Something went wrong while getting applicatant details", e);
		}
	}

	public Scholarship setApplicationStatus(Scholarship scholarship) throws ScholarshipException {
		try
		{
			entityManager.merge(scholarship);
			return scholarship;
		}
	
		catch(Exception e)
		{
			throw new ScholarshipException("OOP's!!! Something went wrong while setting application details", e);
		}
	}

	public Scholarship insertNewScholarship(Scholarship scholarship) throws ScholarshipException {
		try
		{
			entityManager.persist(scholarship);
			return scholarship;
		}
	
		catch(Exception e)
		{
			throw new ScholarshipException("OOP's!!! Something went wrong while inserting a new student", e);
		}
	}
	
}