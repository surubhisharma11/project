package com.lti.project.services;

import com.lti.project.entity.Login;
import com.lti.project.exception.LoginException;

public interface LoginService 
{
	public Login insertNewStudent(Login login) throws LoginException;
	public int loginCheck(Login login) throws LoginException;
	//public Login loginCheck(Login login) throws LoginException;
}
