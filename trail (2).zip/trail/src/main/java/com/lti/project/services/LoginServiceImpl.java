package com.lti.project.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.project.daos.LoginDao;
import com.lti.project.entity.Login;
import com.lti.project.exception.LoginException;

@Service("LoginServiceImpl")
@Transactional(propagation= Propagation.REQUIRED)
public class LoginServiceImpl implements LoginService
{
	@Autowired
	LoginDao loginDao;

	@Override
	public Login insertNewStudent(Login login) throws LoginException 
	{
		return loginDao.insertNewStudent(login);
	}

	@Override
	public int loginCheck(Login login) throws LoginException 
	{
		return loginDao.loginCheck(login);
	}

}
